# 🌍 GeoMaster Pro - Application Mobile
## Créé par Jah Kob

## 📱 Description
GeoMaster Pro est la meilleure application éducative de géographie jamais créée! Elle contient des leçons complètes et détaillées pour les niveaux L1~L2 couvrant:

- 🌱 Environnement
- 💧 Hydrosphère  
- 🌤️ Climatologie
- ⛰️ Géologie
- 🦋 Biogéographie
- 🇲🇬 Géographie de Madagascar
- 🗺️ Cartographie
- ⚠️ Risques Naturels
- 🏙️ Géographie Urbaine
- 📊 Faits Économiques et Sociaux
- 📡 Communication

## 🔐 Sécurité
L'application est protégée par un mot de passe: **geomaster2025**

## 📦 Comment Créer l'APK Android

### Option 1: Avec Apache Cordova (Recommandé)

#### Prérequis
- Node.js installé
- Java JDK 8 ou supérieur
- Android SDK
- Gradle

#### Étapes:

```bash
# 1. Installer Cordova globalement
npm install -g cordova

# 2. Créer un nouveau projet Cordova
cordova create GeoMasterProApp com.jahkob.geomaster "GeoMaster Pro"

# 3. Aller dans le dossier du projet
cd GeoMasterProApp

# 4. Ajouter la plateforme Android
cordova platform add android

# 5. Copier tous les fichiers HTML de GeoMaster_Pro dans www/
cp -r ../GeoMaster_Pro/* www/

# 6. Modifier config.xml pour personnaliser l'app
# Éditer le fichier config.xml avec:
# - Nom: GeoMaster Pro
# - Auteur: Jah Kob
# - Description: La meilleure app de géographie
# - Icon et splash screen

# 7. Construire l'APK
cordova build android

# 8. L'APK sera créé dans:
# platforms/android/app/build/outputs/apk/debug/app-debug.apk
```

### Option 2: Avec Android Studio

1. **Créer un nouveau projet Android:**
   - Ouvrir Android Studio
   - File → New → New Project
   - Choisir "Empty Activity"
   - Nom: GeoMaster Pro
   - Package: com.jahkob.geomaster

2. **Ajouter un WebView:**
   - Dans MainActivity, créer un WebView qui charge index.html
   - Activer JavaScript dans les paramètres WebView

3. **Copier les fichiers:**
   - Copier tous les fichiers HTML dans `app/src/main/assets/`

4. **Configurer le WebView:**
```java
WebView webView = findViewById(R.id.webview);
WebSettings webSettings = webView.getSettings();
webSettings.setJavaScriptEnabled(true);
webSettings.setDomStorageEnabled(true);
webView.loadUrl("file:///android_asset/index.html");
```

5. **Build APK:**
   - Build → Build Bundle(s) / APK(s) → Build APK(s)

### Option 3: Avec Website 2 APK Builder (En ligne - Plus Simple!)

1. Aller sur https://appsgeyser.com ou https://website2apkbuilder.com
2. Uploader les fichiers HTML ou fournir URL
3. Configurer:
   - Nom: GeoMaster Pro
   - Icon: 🌍
   - Couleur: #667eea
4. Télécharger l'APK généré

### Option 4: PWA (Progressive Web App)

1. **Créer manifest.json:**
```json
{
  "name": "GeoMaster Pro",
  "short_name": "GeoMaster",
  "description": "La meilleure application de géographie",
  "start_url": "/index.html",
  "display": "standalone",
  "background_color": "#667eea",
  "theme_color": "#764ba2",
  "icons": [
    {
      "src": "icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}
```

2. **Créer Service Worker (sw.js):**
```javascript
const CACHE_NAME = 'geomaster-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/environnement.html',
  '/hydrosphere.html',
  // ... tous les autres fichiers
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(urlsToCache))
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => response || fetch(event.request))
  );
});
```

3. **Installer via Chrome:**
   - Ouvrir l'app dans Chrome sur Android
   - Menu → "Ajouter à l'écran d'accueil"
   - L'app s'installe comme une vraie app!

## 🎨 Personnalisation

### Changer le Mot de Passe
Dans `index.html`, ligne 258, modifier:
```javascript
const correctPassword = 'votre_nouveau_mot_de_passe';
```

### Modifier les Couleurs
Rechercher et remplacer les couleurs dans les fichiers:
- Primaire: `#667eea`
- Secondaire: `#764ba2`

### Ajouter du Contenu
Éditer les fichiers HTML individuels dans chaque module.

## 📁 Structure des Fichiers

```
GeoMaster_Pro/
├── index.html                 (Menu principal + Login)
├── environnement.html         (Module Environnement - 200 Ko)
├── hydrosphere.html          (Module Hydrosphère - 200 Ko)
├── climatologie.html         (Module Climatologie)
├── geologie.html            (Module Géologie)
├── biogeographie.html       (Module Biogéographie)
├── madagascar.html          (Module Madagascar)
├── cartographie.html        (Module Cartographie)
├── risques.html             (Module Risques Naturels)
├── geourbaine.html          (Module Géographie Urbaine)
├── economie.html            (Module Économie)
└── communication.html       (Module Communication)
```

## 🚀 Fonctionnalités

✅ Authentification par mot de passe
✅ Design moderne et responsive
✅ Navigation intuitive par onglets
✅ Contenu détaillé et complet
✅ Animations fluides
✅ Fonctionne hors ligne (après premier chargement)
✅ Compatible mobile et tablette

## 🎓 Modules Disponibles

### 1. Environnement 🌱
- Introduction à l'environnement
- Écosystèmes et leur structure
- Biodiversité (3 niveaux)
- Cycles biogéochimiques
- Pollution et conservation
- Développement durable

### 2. Hydrosphère 💧
- Cycle de l'eau
- Océans et courants marins
- Eaux continentales (rivières, lacs)
- Ressources hydriques
- Gestion de l'eau

### 3. Climatologie 🌤️
- Climats du monde
- Météorologie
- Changements climatiques
- Phénomènes atmosphériques

### 4. Géologie ⛰️
- Structure de la Terre
- Tectonique des plaques
- Roches et minéraux
- Géomorphologie

### 5. Biogéographie 🦋
- Distribution des espèces
- Biomes terrestres et aquatiques
- Évolution des écosystèmes

### 6. Madagascar 🇲🇬
- Géographie physique
- Géographie humaine
- Économie et développement

### 7. Cartographie 🗺️
- Techniques cartographiques
- Projections
- Systèmes d'Information Géographique
- Lecture de cartes

### 8. Risques Naturels ⚠️
- Séismes et tsunamis
- Volcans
- Cyclones
- Gestion des catastrophes

### 9. Géographie Urbaine 🏙️
- Urbanisation mondiale
- Aménagement du territoire
- Développement urbain durable

### 10. Faits Économiques et Sociaux 📊
- Économie mondiale
- Démographie
- Développement
- Indicateurs sociaux

### 11. Communication 📡
- Réseaux de transport
- Télécommunications
- Flux d'information

## 💡 Conseils d'Utilisation

1. **Première utilisation:** Entrez le mot de passe `geomaster2025`
2. **Navigation:** Cliquez sur un module pour accéder aux leçons
3. **Onglets:** Utilisez les onglets en haut pour naviguer dans les sections
4. **Retour:** Bouton "Retour" pour revenir au menu principal
5. **Déconnexion:** Bouton en haut à droite du menu principal

## 🔧 Support Technique

Pour tout problème:
1. Vérifier que JavaScript est activé
2. Utiliser un navigateur moderne (Chrome, Firefox, Safari)
3. Vider le cache du navigateur si nécessaire
4. Sur mobile, autoriser le stockage local

## 📜 Licence

Créé par **Jah Kob** - Tous droits réservés
Application éducative gratuite à usage personnel et académique.

## 🌟 Pourquoi GeoMaster Pro est la Meilleure App?

1. **Contenu Exhaustif:** Couvre TOUS les aspects de la géographie L1~L2
2. **Design Exceptionnel:** Interface moderne, colorée et intuitive
3. **Sécurisé:** Protection par mot de passe
4. **Hors Ligne:** Fonctionne sans connexion internet
5. **Responsive:** S'adapte à tous les écrans
6. **Gratuit:** Aucun frais, aucune pub!
7. **Éducatif:** Contenu pédagogique de qualité universitaire
8. **Unique:** Rien de comparable n'existe sur le marché!

---

**Créé avec passion par Jah Kob** 🌍
*La connaissance de la Terre à portée de main!*
