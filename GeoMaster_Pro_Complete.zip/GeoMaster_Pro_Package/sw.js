// GeoMaster Pro Service Worker
// Créé par Jah Kob

const CACHE_NAME = 'geomaster-pro-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/environnement.html',
  '/hydrosphere.html',
  '/climatologie.html',
  '/geologie.html',
  '/biogeographie.html',
  '/madagascar.html',
  '/cartographie.html',
  '/risques.html',
  '/geourbaine.html',
  '/economie.html',
  '/communication.html',
  '/manifest.json'
];

// Installation du Service Worker
self.addEventListener('install', event => {
  console.log('[Service Worker] Installation en cours...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('[Service Worker] Mise en cache des fichiers');
        return cache.addAll(urlsToCache);
      })
      .then(() => {
        console.log('[Service Worker] Installation réussie!');
        return self.skipWaiting();
      })
  );
});

// Activation du Service Worker
self.addEventListener('activate', event => {
  console.log('[Service Worker] Activation en cours...');
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            console.log('[Service Worker] Suppression ancien cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      console.log('[Service Worker] Activation réussie!');
      return self.clients.claim();
    })
  );
});

// Interception des requêtes
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Retourner la réponse du cache si disponible
        if (response) {
          console.log('[Service Worker] Réponse depuis cache:', event.request.url);
          return response;
        }

        // Sinon, faire une requête réseau
        console.log('[Service Worker] Requête réseau:', event.request.url);
        return fetch(event.request).then(response => {
          // Vérifier si la réponse est valide
          if (!response || response.status !== 200 || response.type !== 'basic') {
            return response;
          }

          // Cloner la réponse
          const responseToCache = response.clone();

          // Mettre en cache pour usage futur
          caches.open(CACHE_NAME).then(cache => {
            cache.put(event.request, responseToCache);
          });

          return response;
        });
      }).catch(error => {
        console.log('[Service Worker] Erreur de fetch:', error);
        // Retourner une page d'erreur personnalisée si nécessaire
        return caches.match('/index.html');
      })
  );
});

// Message de synchronisation
self.addEventListener('message', event => {
  if (event.data.action === 'skipWaiting') {
    self.skipWaiting();
  }
});

// Notification de mise à jour
self.addEventListener('sync', event => {
  if (event.tag === 'update-cache') {
    event.waitUntil(
      caches.open(CACHE_NAME).then(cache => {
        return cache.addAll(urlsToCache);
      })
    );
  }
});

console.log('[Service Worker] Chargé et prêt!');
