#!/bin/bash

# GeoMaster Pro - Script de Build APK
# Créé par Jah Kob
# Ce script automatise la création d'un APK Android

echo "╔════════════════════════════════════════════╗"
echo "║     🌍 GeoMaster Pro APK Builder 🌍      ║"
echo "║          Créé par Jah Kob                  ║"
echo "╚════════════════════════════════════════════╝"
echo ""

# Couleurs pour l'affichage
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Fonction pour afficher des messages colorés
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

# Vérifier les prérequis
print_info "Vérification des prérequis..."

check_command() {
    if command -v $1 &> /dev/null; then
        print_success "$1 est installé"
        return 0
    else
        print_warning "$1 n'est pas installé"
        return 1
    fi
}

# Variables
APP_NAME="GeoMaster Pro"
PACKAGE_NAME="com.jahkob.geomaster"
BUILD_DIR="build_apk"
APK_OUTPUT="GeoMasterPro.apk"

echo ""
echo "Choisissez votre méthode de build:"
echo "1) Cordova (Recommandé - APK natif)"
echo "2) PWA to APK (En ligne - Simple)"
echo "3) Capacitor (Moderne)"
echo "4) Instructions manuelles"
echo ""
read -p "Entrez votre choix (1-4): " choice

case $choice in
    1)
        echo ""
        print_info "=== Build avec Apache Cordova ==="
        
        # Vérifier Node.js
        if ! check_command node; then
            print_error "Node.js est requis. Installez-le depuis https://nodejs.org"
            exit 1
        fi
        
        # Installer Cordova si nécessaire
        if ! check_command cordova; then
            print_info "Installation de Cordova..."
            npm install -g cordova
        fi
        
        # Créer le projet Cordova
        print_info "Création du projet Cordova..."
        cordova create "$BUILD_DIR" "$PACKAGE_NAME" "$APP_NAME"
        
        cd "$BUILD_DIR"
        
        # Ajouter la plateforme Android
        print_info "Ajout de la plateforme Android..."
        cordova platform add android
        
        # Copier les fichiers
        print_info "Copie des fichiers de l'application..."
        rm -rf www/*
        cp -r ../GeoMaster_Pro/* www/
        
        # Créer config.xml
        cat > config.xml << 'EOF'
<?xml version='1.0' encoding='utf-8'?>
<widget id="com.jahkob.geomaster" version="1.0.0" xmlns="http://www.w3.org/ns/widgets">
    <name>GeoMaster Pro</name>
    <description>
        La meilleure application de géographie L1~L2
    </description>
    <author email="jahkob@example.com" href="https://example.com">
        Jah Kob
    </author>
    <content src="index.html" />
    <access origin="*" />
    <allow-intent href="http://*/*" />
    <allow-intent href="https://*/*" />
    <preference name="Orientation" value="portrait" />
    <preference name="DisallowOverscroll" value="true" />
    <preference name="BackgroundColor" value="0xff667eea" />
    <platform name="android">
        <preference name="android-minSdkVersion" value="22" />
        <preference name="android-targetSdkVersion" value="33" />
        <allow-intent href="market:*" />
    </platform>
</widget>
EOF
        
        # Build l'APK
        print_info "Build de l'APK (cela peut prendre plusieurs minutes)..."
        cordova build android --release
        
        # Copier l'APK généré
        if [ -f "platforms/android/app/build/outputs/apk/release/app-release-unsigned.apk" ]; then
            cp platforms/android/app/build/outputs/apk/release/app-release-unsigned.apk "../$APK_OUTPUT"
            print_success "APK créé avec succès: $APK_OUTPUT"
            print_info "Note: L'APK n'est pas signé. Pour le signer, utilisez jarsigner."
        else
            print_error "Erreur lors de la création de l'APK"
        fi
        
        cd ..
        ;;
        
    2)
        echo ""
        print_info "=== Conversion PWA to APK en ligne ==="
        echo ""
        print_info "Suivez ces étapes:"
        echo "1. Allez sur https://www.pwabuilder.com/"
        echo "2. Ou https://appsgeyser.com/"
        echo "3. Ou https://gonative.io/"
        echo ""
        print_info "Configuration recommandée:"
        echo "   - Nom: GeoMaster Pro"
        echo "   - Package: com.jahkob.geomaster"
        echo "   - URL de départ: /index.html"
        echo "   - Couleur thème: #667eea"
        echo "   - Orientation: Portrait"
        echo ""
        print_success "Le fichier manifest.json est déjà configuré!"
        print_info "Uploadez simplement le dossier GeoMaster_Pro/"
        ;;
        
    3)
        echo ""
        print_info "=== Build avec Capacitor ==="
        
        if ! check_command npm; then
            print_error "npm est requis"
            exit 1
        fi
        
        print_info "Installation de Capacitor..."
        npm install @capacitor/core @capacitor/cli
        
        print_info "Initialisation du projet..."
        npx cap init "$APP_NAME" "$PACKAGE_NAME" --web-dir=GeoMaster_Pro
        
        print_info "Ajout de la plateforme Android..."
        npx cap add android
        
        print_info "Copie des assets..."
        npx cap copy
        
        print_info "Synchronisation..."
        npx cap sync
        
        print_success "Projet Capacitor créé!"
        print_info "Pour continuer:"
        echo "   1. cd android"
        echo "   2. Ouvrez le projet dans Android Studio"
        echo "   3. Build → Build APK"
        ;;
        
    4)
        echo ""
        print_info "=== Instructions Manuelles ==="
        echo ""
        echo "📱 MÉTHODE 1 - Android Studio:"
        echo "   1. Installez Android Studio"
        echo "   2. Créez un nouveau projet 'Empty Activity'"
        echo "   3. Ajoutez un WebView dans MainActivity"
        echo "   4. Copiez les fichiers dans assets/"
        echo "   5. Build → Build APK"
        echo ""
        echo "🌐 MÉTHODE 2 - Service en ligne (Plus Simple):"
        echo "   Sites recommandés:"
        echo "   • https://www.pwabuilder.com (Gratuit, professionnel)"
        echo "   • https://appsgeyser.com (Simple, gratuit)"
        echo "   • https://gonative.io (Premium mais puissant)"
        echo "   • https://websitetoapk.com (Basique)"
        echo ""
        echo "📦 MÉTHODE 3 - PWA (Progressive Web App):"
        echo "   1. Hébergez les fichiers sur un serveur HTTPS"
        echo "   2. Visitez le site sur Chrome Android"
        echo "   3. Menu → 'Ajouter à l'écran d'accueil'"
        echo "   4. L'app s'installe automatiquement!"
        echo ""
        print_success "Le fichier manifest.json est déjà configuré pour PWA!"
        ;;
        
    *)
        print_error "Choix invalide"
        exit 1
        ;;
esac

echo ""
print_success "╔════════════════════════════════════════════╗"
print_success "║         Build terminé avec succès!         ║"
print_success "╚════════════════════════════════════════════╝"
echo ""
print_info "Fichiers de l'application dans: GeoMaster_Pro/"
print_info "README complet disponible dans: GeoMaster_Pro/README.md"
echo ""
print_info "Mot de passe de l'app: geomaster2025"
echo ""
print_info "Créé avec ❤️ par Jah Kob"
echo "🌍 La connaissance de la Terre à portée de main! 🌍"
